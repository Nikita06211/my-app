export const AboutUs = ()=>{
    return(
        <div>
            About Us
        </div>
    )
}