import React from 'react';
import { Container, Typography, Grid, Button, IconButton } from '@mui/material';
export const Calculator = () => {
    return (
        <div>
            {/* <Grid>
                <Grid 
                    >
                    <img
                        src={process.env.PUBLIC_URL + '/Assets/calculator.png'}
                        alt="cal Image"
                        style={{ width: "100%", height: "20%" }}
                    />
                </Grid> */}


            {/* </Grid> */}

        </div>
    );
};

